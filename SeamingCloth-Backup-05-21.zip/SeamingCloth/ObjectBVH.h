#pragma once
#include"BVH.h"
#include<GraphicHelper/Model.h>

namespace Lyra
{
	template<typename T> class ObjectBVH;
}

namespace Lyra
{
	template<typename T>
	class ObjectBVH
	{
	public:
		ObjectBVH() = default;

		/*Interface to private data memeber*/
		std::vector<BVHFlatNode<T>>& FlatBVHTree() { return flatBvhTree; }
		std::vector<BBoxObjTriangle<T>>& Fragments() { return fragments; }
		uint32 NLevel() { return nLevel; }

		void Build(ModelPointer<T>& model, uint32 leafSize=4, shader_sp<T> shader = nullptr, bool draw = false);
		void DebugGlDraw(Camera<T>& camera);
		void DebugGlBind();

		void GlDraw(Camera<T>& camera);
		void GlBind();

	private:
		void Init(ModelPointer<T>& model);
		void DebugCreate(shader_sp<T> shader, bool draw);
		void DebugTrversal();

		void Create(uint32 leafSize, shader_sp<T> shader, bool draw);

	private:
		std::vector<BBoxObjTriangle<T>> fragments;
		std::vector<BBox<T>> bBoxes;
		std::vector<BVHFlatNode<T>> flatBvhTree;
		uint32 nNodes, nLeafs, leafSize, nLevel;
	};

	template<typename T>
	using objectBvh_sp = std::shared_ptr<ObjectBVH<T>>;
	template<typename T>
	using objectBvh_up = std::unique_ptr<ObjectBVH<T>>;
	template<typename T>
	using objectBvh_pt = ObjectBVH<T>*;
}

template<typename T>
void Lyra::ObjectBVH<T>::DebugGlBind()
{
	for (auto& bbox : bBoxes) {
		bbox.GlBind();
	}
}

template<typename T>
void Lyra::ObjectBVH<T>::DebugGlDraw(Camera<T>& camera)
{
	for (auto& bbox : bBoxes) {
		bbox.GlDraw(camera);
	}
}

template<typename T>
void Lyra::ObjectBVH<T>::GlDraw(Camera<T>& camera)
{
	for (auto& flatNode : flatBvhTree) {
			flatNode.bBox.GlDraw(camera);
	}
}

template<typename T>
void Lyra::ObjectBVH<T>::GlBind()
{
	glm::vec<3, T> color;
	ColorMapper<T> mapper;
	uint32 totalLevel = ceil(std::log2(flatBvhTree.size()));

	for (auto& flatNode : flatBvhTree) {
		T tmp = (flatNode.level + 1) / T(totalLevel + 1);
		mapper.GetGlmColor(tmp, Lyra::ColorMap::COLOR__MAGMA, color);
		flatNode.bBox.GlInit(color);
	}
}

template<typename T>
void Lyra::ObjectBVH<T>::Build(ModelPointer<T> & model, uint32 leafSize, shader_sp<T> shader, bool draw)
{
	//std::cout << "Object BVH Build Start.....\n";
	//��ȡOBJ��triangle��Ϣ
	Init(model);
	Create(leafSize, shader, draw);
	//DebugTrversal();

	/*for (uint32 i = 0; i < flatBvhTree.size(); i++) {
		if (flatBvhTree[i].rightOffset == 0) {
			std::cout << flatBvhTree[i].start << "\n";
		}
	}
	system("pause");*/
	//DebugCreate(shader, draw);
	//std::cout << "Object BVH Build End!!!\n";
}

template<typename T>
void Lyra::ObjectBVH<T>::Create(uint32 leafSize, shader_sp<T> shader, bool draw)
{
	//top-down to build BVH
	std::stack<BVHBuildEntry> todo;
	BVHBuildEntry root, curNode;
	BVHFlatNode<T> node;

	root.start = 0;
	root.end = fragments.size();
	root.parent = BvhMagicNumber::ROOT_PARENT;
	root.level = 0;

	todo.push(root);

	//resize���ʼ��������ڴ棬reserve����
	flatBvhTree.reserve(fragments.size() * 2);

	while (!todo.empty()) {
		/////////////////////////To Build This Level's BBox//////////////////////////////////////
		BVHBuildEntry& bNode(todo.top());
		todo.pop();
		uint32_t startTmp = bNode.start;
		uint32_t endTmp = bNode.end;
		uint32_t nPrims = endTmp - startTmp;

		nNodes++;
		node.start = startTmp;
		node.nPrims = nPrims;
		node.rightOffset = BvhMagicNumber::UNTOUCHED;
		node.level = bNode.level;

		BBox<T> bb(fragments[startTmp].GetBBox(shader, false));
		//bc���ڹ�������OBJ������λ��,����Ҫ��Ⱦ����
		BBox<T> bc(fragments[startTmp].GetCentroid(), shader, false);

		for (uint32 p = startTmp + 1; p < endTmp; p++) {
			bb.ExpandToInclude(fragments[p].GetBBox(shader, false));
			bc.ExpandToInclude(fragments[p].GetCentroid());
		}
		node.bBox = bb;

		if (nPrims <= leafSize) {
			node.rightOffset = BvhMagicNumber::LEAF;
			nLeafs++;
		}

		flatBvhTree.push_back(node);

		if (bNode.parent != BvhMagicNumber::ROOT_PARENT) {
			flatBvhTree[bNode.parent].rightOffset--;
			if (flatBvhTree[bNode.parent].rightOffset == BvhMagicNumber::TOUCHEDTWICE) {
				flatBvhTree[bNode.parent].rightOffset = nNodes - 1 - bNode.parent;
			}
		}

		if (node.rightOffset == BvhMagicNumber::LEAF)
			continue;

		///////////////////////////partition//////////////////////////////////////////////
		uint32 splitDim = bc.MaxDimension();
		T splitCoord = T(1) / 2 * (bc.minCorner(splitDim) + bc.maxCorner(splitDim));

		uint32 mid = startTmp;
		for (uint32 i = startTmp; i < endTmp; i++) {
			if (fragments[i].GetCentroid()[splitDim] < splitCoord)
				std::swap(fragments[i], fragments[mid]);
			++mid;
		}

		if (mid == startTmp || mid == endTmp) {
			mid = startTmp + (endTmp - startTmp) / T(2);
		}

		curNode.start = mid;
		curNode.end = endTmp;
		curNode.parent = nNodes - 1;
		curNode.level = flatBvhTree[curNode.parent].level + 1;
		//std::cout << curNode.level << "\n\n";
		todo.push(curNode);

		curNode.start = startTmp;
		curNode.end = mid;
		curNode.parent = nNodes - 1;
		curNode.level = flatBvhTree[curNode.parent].level + 1;

		//system("pause");
		todo.push(curNode);
	}

	nLevel = ceil(std::log2(flatBvhTree.size()));
}

template<typename T>
void Lyra::ObjectBVH<T>::DebugCreate(shader_sp<T> shader, bool draw)
{
	for (auto& frag : fragments) {
		bBoxes.push_back(frag.GetBBox(shader, draw));
	}
}

template<typename T>
void Lyra::ObjectBVH<T>::Init(ModelPointer<T> & model)
{
	auto& mesh = model->Meshes()[0];
	auto& triangles = mesh.Triangles();

	for (auto& tri : triangles) {

		fragments.push_back(BBoxObjTriangle<T>(tri.V1(), tri.V2(), tri.V3()));
	}
}

template<typename T>
void Lyra::ObjectBVH<T>::DebugTrversal()
{
	std::vector<bool> isVisited;
	isVisited.resize(fragments.size(), false);

	uint32 root = 0;
	std::stack<uint32> s;
	s.push(root);
	while (!s.empty()) {
		uint32 cur = s.top();
		s.pop();

		if (flatBvhTree[cur].rightOffset == 0) {
			for (uint32 i = 0; i < flatBvhTree[cur].nPrims; i++) {
				isVisited[flatBvhTree[cur].start + i] = true;
			}
		}
		else {
			s.push(cur + flatBvhTree[cur].rightOffset);
			s.push(cur + 1);
		}
	}

	for (uint32 i = 0; i < isVisited.size(); i++) {
		if (!isVisited[i]) {
			std::cout << "BVH of Object do not build correctly!!!\n";
			system("pause");
			exit(0);
		}
	}
}