#version 330 core
out vec4 FragColor;

void main()
{    
    FragColor = vec4(0.4,0.8,1.0,1.0);
}