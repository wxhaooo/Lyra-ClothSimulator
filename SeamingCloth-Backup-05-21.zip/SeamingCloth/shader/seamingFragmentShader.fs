#version 330 core
out vec4 FragColor;

void main()
{    
    FragColor = vec4(0.52,0.95,0.52,1.0);
}