#version 330 core
out vec4 FragColor;

void main()
{    
    FragColor = vec4(1.,0.8,0.82,1.0);
}